//
// Created by Lenovo on 6/1/2023.
//

#ifndef TEMA_2_NODE_H
#define TEMA_2_NODE_H
#include <iostream>


class node{
    int value;              // Valoarea stocată în nod
    node *next_node;        // Pointer către următorul nod din listă


public:
    explicit node(int value_=0, node *next_node_= nullptr);
    // Constructorul clasei `node`

    void set_value(int value_);             // Setează valoarea nodului cu valoarea specificată
    int get_value() const;                  // Returnează valoarea stocată în nod

    void set_next_node(node *next_node_);   // Setează pointer-ul către următorul nod din listă
    node* get_next_node();                   // Returnează pointer-ul către următorul nod din listă


};




#endif //TEMA_2_NODE_H
