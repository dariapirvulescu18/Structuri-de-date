#include <iostream>
#include "lista.h"

void Josh( lista &lista1,int k, int index)
{
    // Base case , when only one person is left
    if (lista1.getSize() == 1){
        lista1.print();
        return;
    }

    // find the index of first person which will die
    index = ((index + k-1) % lista1.getSize());

    // remove the first person which is going to be killed
    lista1.delete_index(index);

    // recursive call for n-1 persons
    Josh(lista1,k, index);
}
int main() {
    lista listuta;
    listuta.search_node(9);
    listuta.insert(5);
    listuta.print();
    listuta.insert(7);
    listuta.insert(10);
    listuta.insert(9);
    listuta.insert(9);
    listuta.print();
    listuta.deletee(9);
    listuta.deletee(5);
    listuta.insert(6);
    listuta.print();

    std::cout<<listuta.thirdElement(9);

    lista lista1;
    //problema lui Josephus
    int n ,k;
    std::cin>>n>>k;
    int index;
    std::cin>>index;
    lista1.create_n(n);

    Josh( lista1,k, index);
    return 0;
}
