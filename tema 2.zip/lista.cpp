#include "lista.h"

// Inserează un nou nod în listă
void lista::insert(int val){
    node *node_new = new node(val);
    if(head == nullptr)
    {
        // Dacă lista este goală, nodul nou devine capul și coada listei
        head=node_new;
        tail=head;
        tail->set_next_node(head);
        head->set_next_node(tail);
    }
    else{
        // Altfel, se adaugă nodul nou la sfârșitul listei și se actualizează coada și legăturile circulare
        tail->set_next_node(node_new);
        tail=node_new;
        tail->set_next_node(head);
    }
    size++;
}

// Afișează elementele listei
void lista::print() {
    node *pointer = head;
    if (head != nullptr) {
        // Afișează valoarea capului
        std::cout << head->get_value() << " ";
        pointer = pointer->get_next_node(); // Mută pointerul la următorul nod
    }
    while (pointer != head) {
        // Afișează valoarea nodului și mută pointerul la următorul nod
        std::cout << pointer->get_value() << " ";
        pointer = pointer->get_next_node();
    }
    std::cout << "\n";
}

// Creează o listă cu n elemente
void lista::create_n(int n){
    for(int i=0;i<n;i++)
    {
        // Inserează fiecare valoare în listă
        this->insert(i);
    }
    size=n;
}

// Șterge un nod cu o anumită valoare din listă
void lista::deletee(int valu){
    node *pointer_c=head;
    node *pointer_p= nullptr;
    if(valu==pointer_c->get_value())
    {
        // Dacă valoarea de șters se află în capul listei, se actualizează capul și se șterge nodul
        head=head->get_next_node();
        tail->set_next_node(head); // Actualizează legătura circulară
        delete pointer_c;
        size--;

    }
    else {
        // Altfel, se caută valoarea în restul listei
        pointer_p=pointer_c;
        pointer_c=pointer_c->get_next_node();

        while (pointer_c != head) {
            if (pointer_c->get_value() == valu) {
                // Dacă valoarea este găsită, se actualizează legăturile pentru a elimina nodul
                //verificam daca nodul este coada
                if(pointer_c==tail)
                {
                    tail=pointer_p;
                    tail->set_next_node(head);
                }
                else{
                    pointer_p->set_next_node(pointer_c->get_next_node());
                }

                delete pointer_c;
                size--;
                break;
            }
            else{
                // Se mută pointerii la următorul nod
                pointer_p = pointer_c;
                pointer_c = pointer_c->get_next_node();

            }

        }
    }

}

// Caută un nod cu o anumită valoare și returnează apartia sa în listă
node * lista::search_node(int v){
    node *pointer_c=head;
    if(head!= nullptr){
        do
        {
            if(pointer_c->get_value()==v)
                // Dacă valoarea este găsită, se returnează prima apartie a ei în listă
                return pointer_c;
            pointer_c=pointer_c->get_next_node();
        } while (pointer_c != head);

    }

    // Dacă valoarea nu este găsită, se returnează nullptr
    return nullptr;
}


// Returnează valoarea celui de-al treilea element în lista circulară, începând de la un nod dat
int lista::thirdElement(int value) {

    // Verifică dacă valoarea dată se găsește în listă
    if (search_node(value) == nullptr){
        // Dacă valoarea nu este găsită în listă, se returnează -1
        return -1;
    }
    else {
        // Dacă valoarea este găsită în listă, se mută pointerul la nodul cu valoarea dată
        // Returnează valoarea celui de-al treilea element
        return search_node(value)->get_next_node()->get_next_node()->get_next_node()->get_value();
    }

}

int lista::getSize() const {
    return size;
}

void lista::delete_index(int index) {
    node *pointer_c=head;
    node *pointer_p= nullptr;
    if(index==0)
    {
        // Dacă indexul este 0, se actualizează capul și se șterge nodul
        head=head->get_next_node();
        tail->set_next_node(head); // Actualizează legătura circulară
        delete pointer_c;
        size--;

    }
    else {
        // Altfel, se caută indexul în restul listei
        pointer_p=pointer_c;
        pointer_c=pointer_c->get_next_node();
        int i=1;
        while (i<index) {
               // Se mută pointerii la următorul nod
                pointer_p = pointer_c;
                pointer_c = pointer_c->get_next_node();
                i++;


        }
        // trebuie sa stergem pointer_c
        //verificam daca nodul este coada
        if(pointer_c==tail)
        {
            tail=pointer_p;
            tail->set_next_node(head);
        }
        else{
            if(pointer_c==head){
                head=head->get_next_node();
                tail->set_next_node(head);
            }
            else{
                pointer_p->set_next_node(pointer_c->get_next_node());
            }

        }
        delete pointer_c;
        size--;
    }

}




