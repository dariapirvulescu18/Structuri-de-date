//
// Created by Lenovo on 6/5/2023.
//

#include "AVLtree.h"


int AVLTree::getHeight(AVLNode* node) {
    if (node == nullptr)
        return 0;
    return node->height;
}

int AVLTree::getBalance(AVLNode* node) {
    if (node == nullptr)
        return 0;
    return getHeight(node->left) - getHeight(node->right);
}

AVLNode* AVLTree::rightRotate(AVLNode* y) {
    AVLNode* x = y->left;
    AVLNode* T2 = x->right;

    // Efectuăm rotirea spre dreapta
    x->right = y;
    y->left = T2;

    // Actualizăm înălțimile nodurilor modificate
    y->height = max(getHeight(y->left), getHeight(y->right)) + 1;
    x->height = max(getHeight(x->left), getHeight(x->right)) + 1;

    return x;
}

AVLNode* AVLTree::leftRotate(AVLNode* x) {
    AVLNode* y = x->right;
    AVLNode* T2 = y->left;

    // Efectuăm rotirea spre stânga
    y->left = x;
    x->right = T2;

    // Actualizăm înălțimile nodurilor modificate
    x->height = max(getHeight(x->left), getHeight(x->right)) + 1;
    y->height = max(getHeight(y->left), getHeight(y->right)) + 1;

    return y;
}

AVLNode* AVLTree::insertNode(AVLNode* node, double key, const pair<int, int>& indices) {
    if (node == nullptr)
        return new AVLNode(key, indices);

    if (key < node->key)
        node->left = insertNode(node->left, key, indices);
    else if (key > node->key)
        node->right = insertNode(node->right, key, indices);
    else
        return node;

    // Actualizăm înălțimea nodului curent
    node->height = 1 + max(getHeight(node->left), getHeight(node->right));

    // Verificăm factorul de balans al nodului pentru a menține proprietatea AVL
    int balance = getBalance(node);

    // Cazul în care nodul devine neechilibrat din stânga-stânga
    if (balance > 1 && key < node->left->key)
        return rightRotate(node);

    // Cazul în care nodul devine neechilibrat din dreapta-dreapta
    if (balance < -1 && key > node->right->key)
        return leftRotate(node);

    // Cazul în care nodul devine neechilibrat din stânga-dreapta
    if (balance > 1 && key > node->left->key) {
        node->left = leftRotate(node->left);
        return rightRotate(node);
    }

    // Cazul în care nodul devine neechilibrat din dreapta-stânga
    if (balance < -1 && key < node->right->key) {
        node->right = rightRotate(node->right);
        return leftRotate(node);
    }

    return node;
}

AVLNode* AVLTree::minValueNode(AVLNode* node) {
    AVLNode* current = node;

    // Găsim cel mai mic nod din subarborele stâng
    while (current->left != nullptr)
        current = current->left;

    return current;
}

AVLNode* AVLTree::deleteNode(AVLNode* root, double key) {
    if (root == nullptr)
        return root;

    if (key < root->key)
        root->left = deleteNode(root->left, key);
    else if (key > root->key)
        root->right = deleteNode(root->right, key);
    else {
        // Nodul de eliminat are unul sau niciun copil
        if (root->left == nullptr || root->right == nullptr) {
            AVLNode* temp = root->left ? root->left : root->right;

            // Nodul de eliminat nu are copii
            if (temp == nullptr) {
                temp = root;
                root = nullptr;
            } else
                *root = *temp;

            delete temp;
        } else {
            // Nodul de eliminat are doi copii
            AVLNode* temp = minValueNode(root->right);

            // Copiem cheia și indicii segmentului din nodul de minim în nodul curent
            root->key = temp->key;
            root->segmentIndices = temp->segmentIndices;

            // Ștergem nodul de minim din subarborele drept
            root->right = deleteNode(root->right, temp->key);
        }
    }

    if (root == nullptr)
        return root;

    // Actualizăm înălțimea nodului curent
    root->height = 1 + max(getHeight(root->left), getHeight(root->right));

    // Verificăm factorul de balans al nodului pentru a menține proprietatea AVL
    int balance = getBalance(root);

    // Cazul în care nodul devine neechilibrat din stânga-stânga
    if (balance > 1 && getBalance(root->left) >= 0)
        return rightRotate(root);

    // Cazul în care nodul devine neechilibrat din stânga-dreapta
    if (balance > 1 && getBalance(root->left) < 0) {
        root->left = leftRotate(root->left);
        return rightRotate(root);
    }

    // Cazul în care nodul devine neechilibrat din dreapta-dreapta
    if (balance < -1 && getBalance(root->right) <= 0)
        return leftRotate(root);

    // Cazul în care nodul devine neechilibrat din dreapta-stânga
    if (balance < -1 && getBalance(root->right) > 0) {
        root->right = rightRotate(root->right);
        return leftRotate(root);
    }

    return root;
}

void AVLTree::inorderTraversal(AVLNode* root) {
    if (root == nullptr)
        return;

    // Parcurgem în ordine înfixă arborele AVL și afișăm punctele de intersectie
    inorderTraversal(root->left);
    cout << "Punctele de intersectie: (" << root->key << ", " << root->key << ")" << endl;
    cout << "Intersectia se face intre seg: " << root->segmentIndices.first << " si " << root->segmentIndices.second << endl;
    inorderTraversal(root->right);
}

AVLTree:: AVLTree() : root(nullptr) {}

void AVLTree::insert(double key, const pair<int, int>& indices) {
    root = insertNode(root, key, indices);
}

void AVLTree::remove(double key) {
    root = deleteNode(root, key);
}

void AVLTree::traverse() {
    inorderTraversal(root);
}

bool AVLTree::isEmpty() {
    return root == nullptr;
}
