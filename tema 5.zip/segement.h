//
// Created by Lenovo on 6/5/2023.
//

#ifndef TEMA_5_SEGEMENT_H
#define TEMA_5_SEGEMENT_H
#include "point.h"
#include <iostream>

class Segment {
public:
    Point start; // Punctul de inceput al segmentului
    Point end;  // Punctul de sfarsit al segmentului

    Segment(const Point& start, const Point& end) ;
};


#endif //TEMA_5_SEGEMENT_H
