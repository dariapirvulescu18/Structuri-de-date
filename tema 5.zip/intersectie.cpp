//
// Created by Lenovo on 6/5/2023.
//
#include "intersectie.h"
bool intersectie::seIntersecteaza(const Segment& seg1, const Segment& seg2) {
    // Verifica orientarea segmentelor pentru a determina daca se intersecteaza
    double orientation1 = (seg2.start.y - seg1.start.y) * (seg1.end.x - seg1.start.x) -
                          (seg2.start.x - seg1.start.x) * (seg1.end.y - seg1.start.y);
    double orientation2 = (seg2.end.y - seg1.start.y) * (seg1.end.x - seg1.start.x) -
                          (seg2.end.x - seg1.start.x) * (seg1.end.y - seg1.start.y);
    double orientation3 = (seg1.start.y - seg2.start.y) * (seg2.end.x - seg2.start.x) -
                          (seg1.start.x - seg2.start.x) * (seg2.end.y - seg2.start.y);
    double orientation4 = (seg1.end.y - seg2.start.y) * (seg2.end.x - seg2.start.x) -
                          (seg1.end.x - seg2.start.x) * (seg2.end.y - seg2.start.y);

    return (orientation1 * orientation2 < 0) && (orientation3 * orientation4 < 0);
}

Point intersectie::calculaareUndeSeIntersecteaza(const Segment& seg1, const Segment& seg2) {
    // Calculeaza punctul de intersectie al doua segmente
    double x1 = seg1.start.x;
    double y1 = seg1.start.y;
    double x2 = seg1.end.x;
    double y2 = seg1.end.y;
    double x3 = seg2.start.x;
    double y3 = seg2.start.y;
    double x4 = seg2.end.x;
    double y4 = seg2.end.y;

    double intersectionX = ((x1 * y2 - y1 * x2) * (x3 - x4) - (x1 - x2) * (x3 * y4 - y3 * x4)) /
                           ((x1 - x2) * (y3 - y4) - (y1 - y2) * (x3 - x4));
    double intersectionY = ((x1 * y2 - y1 * x2) * (y3 - y4) - (y1 - y2) * (x3 * y4 - y3 * x4)) /
                           ((x1 - x2) * (y3 - y4) - (y1 - y2) * (x3 - x4));

    return Point(intersectionX, intersectionY);
}

void intersectie::gasestePuncteleDeIntersectie(const vector<Segment>& segments) {
    int n = segments.size();

    for (int i = 0; i < n; i++) {
        for (int j = i + 1; j < n; j++) {
            if (seIntersecteaza(segments[i], segments[j])) {
                // Calculeaza punctul de intersectie si il adauga in map
                Point intersection = calculaareUndeSeIntersecteaza(segments[i], segments[j]);
                intersectionPoints[intersection.x] = make_pair(i, j);
            }
        }
    }

    if (intersectionPoints.empty()) {
        cout << "Segmentele nu se intersectează." << endl;
    } else {
        // Afiseaza punctele de intersectie
        auto intersection = intersectionPoints.begin();
        int segmentIndex1 = intersection->second.first;
        int segmentIndex2 = intersection->second.second;

        cout << "Există puncte de intersectare între segmentul " << segmentIndex1 << " și segmentul " << segmentIndex2 << endl;
        cout << "Acestea sunt: (" << intersection->first << ", " << intersection->first << ")" << endl;
    }
}

void intersectie::gasestePctIntersectieAVLtree(const vector<Segment>& segments) {
    int n = segments.size();

    for (int i = 0; i < n; i++) {
        for (int j = i + 1; j < n; j++) {
            if (seIntersecteaza(segments[i], segments[j])) {
                // Calculeaza punctul de intersectie si il insereaza in AVLTree
                Point intersection = calculaareUndeSeIntersecteaza(segments[i], segments[j]);
                intersectionPoints2.insert(intersection.x, make_pair(i, j));
            }
        }
    }

    if (intersectionPoints2.isEmpty()) {
        cout << "Nu există puncte de intersectie." << endl;
    } else {
        intersectionPoints2.traverse();
    }
}
