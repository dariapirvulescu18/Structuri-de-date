//
// Created by Lenovo on 6/5/2023.
//

#ifndef TEMA_5_POINT_H
#define TEMA_5_POINT_H
#include <iostream>

class Point {
public:
    double x; // Coordonata x a punctului
    double y; // Coordonata y a punctului

    Point(double x = 0.0, double y = 0.0) ;
};

#endif //TEMA_5_POINT_H
