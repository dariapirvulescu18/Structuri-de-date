#ifndef TEMA_5_AVLTREE_H
#define TEMA_5_AVLTREE_H

#include <iostream>
#include <vector>
#include "nodeAVL.h"
using namespace std;

class AVLTree {
private:
    AVLNode* root;

public:
    // Funcție pentru obținerea înălțimii unui nod
    int getHeight(AVLNode* node);

    // Funcție pentru obținerea factorului de balans al unui nod
    int getBalance(AVLNode* node);

    // Rotirea spre dreapta a unui nod într-o structură AVL
    AVLNode* rightRotate(AVLNode* y);

    // Rotirea spre stânga a unui nod într-o structură AVL
    AVLNode* leftRotate(AVLNode* x);

    // Inserarea unui nod într-un AVL
    AVLNode* insertNode(AVLNode* node, double key, const pair<int, int>& indices);

    // Găsirea nodului cu valoarea minimă într-un AVL
    AVLNode* minValueNode(AVLNode* node);

    // Ștergerea unui nod dintr-un AVL
    AVLNode* deleteNode(AVLNode* root, double key);

    // Parcurgerea în inordine a unui AVL
    void inorderTraversal(AVLNode* root);

    // Constructorul clasei AVLTree
    AVLTree();

    // Funcție pentru inserarea unui nod în AVL
    void insert(double key, const pair<int, int>& indices);

    // Funcție pentru ștergerea unui nod din AVL
    void remove(double key);

    // Funcție pentru parcurgerea în inordine a unui AVL
    void traverse();

    // Funcție pentru verificarea dacă AVL-ul este gol
    bool isEmpty();
};

#endif //TEMA_5_AVLTREE_H
