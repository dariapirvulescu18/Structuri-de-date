//
// Created by Lenovo on 6/5/2023.
//

#ifndef TEMA_5_INTERSECTIE_H
#define TEMA_5_INTERSECTIE_H
#include <iostream>
#include <vector>
#include <algorithm>
#include <map>
#include "segement.h"
#include "AVLtree.h"
using namespace std;

class intersectie {
private:
    map<double, pair<int, int>> intersectionPoints; // Map pentru stocarea punctelor de intersecție, cheia este coordonata x a punctului, iar valorile sunt indicii segmentelor
    AVLTree intersectionPoints2; // Arbore AVL pentru stocarea punctelor de intersecție, cheia este coordonata x a punctului, iar valorile sunt indicii segmentelor
public:
    bool seIntersecteaza(const Segment& seg1, const Segment& seg2);
    // Verifică dacă două segmente se intersectează

    Point calculaareUndeSeIntersecteaza(const Segment& seg1, const Segment& seg2);
    // Calculează coordonatele punctului de intersecție a două segmente

    void gasestePuncteleDeIntersectie(const vector<Segment>& segments);
    // Găsește toate punctele de intersecție între segmentele date și le stochează în map

    void gasestePctIntersectieAVLtree(const vector<Segment>& segments);
    // Găsește toate punctele de intersecție între segmentele date și le stochează în arbore AVL

};

#endif //TEMA_5_INTERSECTIE_H
