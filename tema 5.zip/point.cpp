//
// Created by Lenovo on 6/5/2023.
//

#include "point.h"


    Point::Point(double x , double y ) : x(x), y(y) {}