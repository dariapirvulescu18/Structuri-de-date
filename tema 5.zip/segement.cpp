//
// Created by Lenovo on 6/5/2023.
//

#include "segement.h"

    Segment::Segment(const Point& start, const Point& end) : start(start), end(end) {}
