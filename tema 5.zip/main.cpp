#include <iostream>
#include <vector>
#include "point.h"
#include "segement.h"
#include "intersectie.h"
using namespace std;

int main() {
    int n;
    cout << "Câte segmente doriți să introduceți?" << endl;
    cin >> n;

    vector<Segment> segments;

    cout << "Coordonatele fiecărui segment:" << endl;
    for (int i = 0; i < n; i++) {
        Point start, end;
        cout << "Segmentul " << i << ":" << endl;
        cout << "Coordonata x a punctului de început: ";
        cin >> start.x;
        cout << "Coordonata y a punctului de început: ";
        cin >> start.y;
        cout << "Coordonata x a punctului de sfârșit: ";
        cin >> end.x;
        cout << "Coordonata y a punctului de sfârșit: ";
        cin >> end.y;
        segments.push_back(Segment(start, end));
    }

    intersectie finder;
    // Cazul folosind std::map
    finder.gasestePuncteleDeIntersectie(segments);
    // Cazul folosind AVLTree
    finder.gasestePctIntersectieAVLtree(segments);

    return 0;
}
