//
// Created by Lenovo on 6/5/2023.
//

#ifndef TEMA_5_NODEAVL_H
#define TEMA_5_NODEAVL_H
#include <iostream>
using namespace std;

class AVLNode {
public:

    double key; // Cheia nodului (coordonata x a punctului de intersectie)
    pair<int, int> segmentIndices; // Indicii segmentelor care se intersecteaza
    AVLNode* left; // Pointer la copilul stang
    AVLNode* right; // Pointer la copilul drept
    int height; // Inaltimea nodului

    AVLNode(double key, const pair<int, int>& indices) ;
};


#endif //TEMA_5_NODEAVL_H
