//
// Created by Lenovo on 6/5/2023.
//

#include "nodeAVL.h"

AVLNode::AVLNode(double key, const pair<int, int>& indices) : key(key), segmentIndices(indices), left(nullptr), right(nullptr), height(1) {}
