#include <iostream>
#include <vector>
#include <string>
#include <ctime>
#include <cstdlib>
#include <chrono>
#include "linked_list.h"
#include "skip_list.h"


// Funcție pentru generarea unui șir de caractere aleatoriu de lungime dată
std::string generateRandomString(int length) {
    static const char alphanum[] = "abcdefghijklmnopqrstuvwxyz";
    std::string randomString;
    // Se generează un șir de caractere aleatoriu de lungime length
    for (int i = 0; i < length; ++i) {
        randomString += alphanum[rand() % (sizeof(alphanum) - 1)];
    }
    return randomString;
}

//functie pentru a masura timpul de inserare in linked list
void measureLinkedListInsertionTime(const std::vector<std::pair<std::string, int>>& elements) {
    // Se creează o listă simplu înlănțuită
    linked_list ll;
    //se porneste timpul
    auto start = std::chrono::steady_clock::now();
    // Se inserează elementele în listă
    for (const auto& element : elements) {
        ll.insert(element.second);
    }
    //se opreste timpul
    auto end = std::chrono::steady_clock::now();
    //se calculeaza durata
    auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(end - start);
    std::cout << "Linked List Insertion Time: " << duration.count() << " milliseconds" << std::endl;
}

//functie pentru a masura timpul de inserare in skip list
void measureSkipListInsertionTime(const std::vector<std::pair<std::string, int>>& elements) {
    // Se creează o skip listă
    skip_list sl(elements.size());
    //se porneste timpul
    auto start = std::chrono::steady_clock::now();
    // Se inserează elementele în skip listă
    for (const auto& element : elements) {
        sl.insert(element.second, element.second);
    }
    //se opreste timpul
    auto end = std::chrono::steady_clock::now();
    //se calculeaza durata
    auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(end - start);
    std::cout << "Skip List Insertion Time: " << duration.count() << " milliseconds" << std::endl;
}

//functie pentru a masura timpul de cautare in linked list
void measureLinkedListSearchTime(const std::vector<std::pair<std::string, int>>& elements) {
    linked_list ll;
    for (const auto& element : elements) {
        ll.insert(element.second);
    }

    std::vector<int> values;
    for (const auto& element : elements) {
        values.push_back(element.second);
    }

    auto start = std::chrono::steady_clock::now();
    for (const auto& value : values) {
        ll.search_node(value);
    }
    auto end = std::chrono::steady_clock::now();
    auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(end - start);
    std::cout << "Linked List Search Time: " << duration.count() << " milliseconds" << std::endl;
}

//functie pentru a masura timpul de cautare in skip list
void measureSkipListSearchTime(const std::vector<std::pair<std::string, int>>& elements) {
    skip_list sl(elements.size());
    for (const auto& element : elements) {
        sl.insert(element.second, element.second);
    }

    std::vector<int> values;
    for (const auto& element : elements) {
        values.push_back(element.second);
    }

    auto start = std::chrono::steady_clock::now();
    for (const auto& value : values) {
        sl.search(value);
    }
    auto end = std::chrono::steady_clock::now();
    auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(end - start);
    std::cout << "Skip List Search Time: " << duration.count() << " milliseconds" << std::endl;
}

//functie pentru a masura timpul de stergere in linked list
void measureLinkedListDeletionTime(const std::vector<std::pair<std::string, int>>& elements) {
    linked_list ll;
    for (const auto& element : elements) {
        ll.insert(element.second);
    }

    std::vector<int> values;
    for (const auto& element : elements) {
        values.push_back(element.second);
    }

    std::vector<int> bits(values.size(), 1);
    std::srand(static_cast<unsigned int>(std::time(nullptr)));

    auto start = std::chrono::steady_clock::now();
    for (int i = 0; i < values.size(); ++i) {
        int index = rand() % values.size();
        if (bits[index] == 1) {
            ll.deletee(values[index]);
            bits[index] = 0;
        }
    }
    auto end = std::chrono::steady_clock::now();
    auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(end - start);
    std::cout << "Linked List Deletion Time: " << duration.count() << " milliseconds" << std::endl;
}

//functie pentru a masura timpul de stergere in skip list
void measureSkipListDeletionTime(const std::vector<std::pair<std::string, int>>& elements) {
    skip_list sl(elements.size());
    for (const auto& element : elements) {
        sl.insert(element.second, element.second);
    }

    std::vector<int> values;
    for (const auto& element : elements) {
        values.push_back(element.second);
    }

    std::vector<int> bits(values.size(), 1);
    std::srand(static_cast<unsigned int>(std::time(nullptr)));

    auto start = std::chrono::steady_clock::now();
    for (int i = 0; i < values.size(); ++i) {
        int index = rand() % values.size();
        if (bits[index] == 1) {
            sl.remove(values[index]);
            bits[index] = 0;
        }
    }
    auto end = std::chrono::steady_clock::now();
    auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(end - start);
    std::cout << "Skip List Deletion Time: " << duration.count() << " milliseconds" << std::endl;
}

int main() {
    //testare linked list si skip list( pentru a vedea ca operațiile de inserare, căutare și ștergere funcționează corect)
//    linked_list list1;
//    list1.create_n(10);
//    list1.print();
//    list1.deletee(5);
//    list1.print();
//    list1.insert(5);
//    list1.print();
//
//
//    skip_list list(10000);
//
//    // Insert nodes
//    list.insert(10, 100);
//    list.insert(5, 50);
//    list.insert(7, 70);
//    list.insert(15, 150);
//
//    // Search for nodes
//    std::cout << "Search 10: " << list.search(10) << std::endl;
//    std::cout << "Search 5: " << list.search(5) << std::endl;
//    std::cout << "Search 7: " << list.search(7) << std::endl;
//    std::cout << "Search 15: " << list.search(15) << std::endl;
//
//    // Delete nodes
//    list.remove(5);
//    list.remove(15);
//
//    // Search again after deletion
//    std::cout << "Search 10: " << list.search(10) << std::endl;
//    std::cout << "Search 5: " << list.search(5) << std::endl;
//    std::cout << "Search 7: " << list.search(7) << std::endl;
//    std::cout << "Search 15: " << list.search(15) << std::endl;
//
    const int numElements = 10000;
    const int keyLength = 10;

    std::vector<std::pair<std::string, int>> elements;

    for (int i = 0; i < numElements; ++i) {
        std::string key = generateRandomString(keyLength);
        int value = rand();
        elements.emplace_back(key, value);
    }

    measureLinkedListInsertionTime(elements);
    measureSkipListInsertionTime(elements);
    measureLinkedListSearchTime(elements);
    measureSkipListSearchTime(elements);
    measureLinkedListDeletionTime(elements);
    measureSkipListDeletionTime(elements);


    return 0;
}
