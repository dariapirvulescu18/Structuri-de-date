//
// Created by Lenovo on 6/1/2023.
//

#include "node.h"

// Definirea constructorului clasei node
node::node(int value_, node *next_node_)
        : value{value_}, next_node{next_node_} {}

// Obține valoarea stocată în nod
[[nodiscard]] int node::get_value() const {
    return value;
}

// Obține pointer-ul către următorul nod
node* node::get_next_node() {
    return next_node;
}

// Setează valoarea nodului
void node::set_value(int value_) {
    value = value_;
}

// Setează pointer-ul către următorul nod
void node::set_next_node(node *next_node_) {
    next_node = next_node_;
}


