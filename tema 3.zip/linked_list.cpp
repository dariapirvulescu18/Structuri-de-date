//
// Created by Lenovo on 6/3/2023.
//

#include "linked_list.h"


// Inserează un nou nod în listă
void linked_list::insert(int val){
    node *node_new = new node(val);
    if(head == nullptr)
    {
        // Dacă lista este goală, nodul nou devine capul și coada listei
        head=node_new;
        tail=head;
        tail->set_next_node(head);
        head->set_next_node(tail);
    }
    else{
        // Altfel, se adaugă nodul nou la sfârșitul listei și se actualizează coada și legăturile circulare
        tail->set_next_node(node_new);
        tail=node_new;
        tail->set_next_node(head);
    }
    size++;
}

// Afișează elementele listei
void linked_list::print() {
    node *pointer = head;
    if (head != nullptr) {
        // Afișează valoarea capului
        std::cout << head->get_value() << " ";
        pointer = pointer->get_next_node(); // Mută pointerul la următorul nod
    }
    while (pointer != head) {
        // Afișează valoarea nodului și mută pointerul la următorul nod
        std::cout << pointer->get_value() << " ";
        pointer = pointer->get_next_node();
    }
    std::cout << "\n";
}

// Creează o listă cu n elemente
void linked_list::create_n(int n){
    for(int i=0;i<n;i++)
    {
        // Inserează fiecare valoare în listă
        this->insert(i);
    }
    size=n;
}

// Șterge un nod cu o anumită valoare din listă
void linked_list::deletee(int valu){
    node *pointer_c=head;
    node *pointer_p= nullptr;
    if(valu==pointer_c->get_value())
    {
        // Dacă valoarea de șters se află în capul listei, se actualizează capul și se șterge nodul
        head=head->get_next_node();
        tail->set_next_node(head); // Actualizează legătura circulară
        delete pointer_c;
        size--;

    }
    else {
        // Altfel, se caută valoarea în restul listei
        pointer_p=pointer_c;
        pointer_c=pointer_c->get_next_node();

        while (pointer_c != head) {
            if (pointer_c->get_value() == valu) {
                // Dacă valoarea este găsită, se actualizează legăturile pentru a elimina nodul
                //verificam daca nodul este coada
                if(pointer_c==tail)
                {
                    tail=pointer_p;
                    tail->set_next_node(head);
                }
                else{
                    pointer_p->set_next_node(pointer_c->get_next_node());
                }

                delete pointer_c;
                size--;
                break;
            }
            else{
                // Se mută pointerii la următorul nod
                pointer_p = pointer_c;
                pointer_c = pointer_c->get_next_node();

            }

        }
    }

}

// Caută un nod cu o anumită valoare și returnează apartia sa în listă
node * linked_list::search_node(int v){
    node *pointer_c=head;
    if(head!= nullptr){
        do
        {
            if(pointer_c->get_value()==v)
                // Dacă valoarea este găsită, se returnează prima apartie a ei în listă
                return pointer_c;
            pointer_c=pointer_c->get_next_node();
        } while (pointer_c != head);

    }

    // Dacă valoarea nu este găsită, se returnează nullptr
    return nullptr;
}



int linked_list::getSize() const {
    return size;
}

