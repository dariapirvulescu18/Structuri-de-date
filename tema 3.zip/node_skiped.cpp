//
// Created by Lenovo on 6/3/2023.
//

#include "node_skiped.h"

// Constructor care initializează cheia cu o valoare dată și setează valoarea și vectorul next la valorile implicite
node_skiped::node_skiped(int k) : key(k), value(0), next() {}

// Returnează cheia nodului
int node_skiped::getKey() const {
    return key;
}

// Setează cheia nodului cu o valoare dată
void node_skiped::setKey(int key) {
    this->key = key;
}

// Returnează valoarea asociată nodului
int node_skiped::getValue() const {
    return value;
}

// Setează valoarea asociată nodului cu o valoare dată
void node_skiped::setValue(int value) {
    this->value = value;
}

// Returnează vectorul next care conține pointeri către nodurile următoare pe niveluri
std::vector<node_skiped*>& node_skiped::getNext() {
    return next;
}

// Setează vectorul next cu un vector dat
void node_skiped::setNext(const std::vector<node_skiped*>& next) {
    this->next = next;
}
