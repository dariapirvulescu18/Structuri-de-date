//
// Created by Lenovo on 6/3/2023.
//

#include "skip_list.h"
// Constructor pentru skip listă, primește numărul de elemente n
    skip_list::skip_list(int n) : head(new node_skiped(-1)), maxLevel(static_cast<int>(std::log2(n))), size(0) {
        head->setNext(std::vector<node_skiped*>(maxLevel, nullptr));
    }
 // Funcție pentru căutarea unei chei în skip listă, returnează valoarea asociată cheii sau -1 dacă cheia nu există
    int  skip_list::search(int key) {
        node_skiped* current = head;
//Parcurgem nivelele skip list-ului de la cel mai înalt nivel până la cel mai mic
        for (int level = maxLevel - 1; level >= 0; level--) {
            //cat timp nu am ajuns la sfarsitul nivelului si cheia nodului curent este mai mica decat cheia cautata
            while (current->getNext()[level] != nullptr && current->getNext()[level]->getKey() < key) {
                current = current->getNext()[level];
            }
        }
//trecem la urmatorul nod
        current = current->getNext()[0];
//daca am ajuns la sfarsitul nivelului 0 si cheia nodului curent este egala cu cheia cautata
        if (current != nullptr && current->getKey() == key) {
            return current->getValue();
        }
        return -1; // nu s-a găsit cheia
    }

// Funcție pentru inserarea unei perechi (cheie, valoare) în skip listă
void  skip_list::insert(int key, int value) {
    //vectorul update va contine pointeri catre nodurile care vor fi actualizate
    std::vector<node_skiped*> update(maxLevel, nullptr);

    //nodul curent va fi initializat cu head
    node_skiped* current = head;
//Parcurgem nivelele skip list-ului de la cel mai înalt nivel până la cel mai mic
    for (int level = maxLevel - 1; level >= 0; level--) {
        //cat timp nu am ajuns la sfarsitul nivelului si cheia nodului curent este mai mica decat cheia cautata
        while (current->getNext()[level] != nullptr && current->getNext()[level]->getKey() < key) {
            current = current->getNext()[level];
        }
        //adaugam nodul curent in vectorul update
        update[level] = current;
    }
    //newLevel va fi nivelul nodului nou(un numar aleatoriu intre 1 si maxLevel)
    int newLevel = getRandomLevel();
    //creem un nou nod cu cheia key si valoarea value
    node_skiped* newNode = new node_skiped(key);
    newNode->setValue(value);
    newNode->setNext(std::vector<node_skiped*>(newLevel, nullptr));
   //parcurgem nivelele nodului nou creat
    for (int level = 0; level < newLevel; level++) {
        newNode->getNext()[level] = update[level]->getNext()[level];
        update[level]->getNext()[level] = newNode;
    }
//marim numarul de elemente din skip list
    size++;
}
// Funcție pentru eliminarea unei chei din skip listă
void  skip_list::remove(int key) {
    //vectorul update va contine pointeri catre nodurile care vor fi actualizate
    std::vector<node_skiped*> update(maxLevel, nullptr);
    node_skiped* current = head;
    //Parcurgem nivelele skip list-ului de la cel mai înalt nivel până la cel mai mic
    for (int level = maxLevel - 1; level >= 0; level--) {
        while (current->getNext()[level] != nullptr && current->getNext()[level]->getKey() < key) {
            current = current->getNext()[level];
        }
        update[level] = current;
    }

    current = current->getNext()[0];
//daca am ajuns la sfarsitul nivelului 0 si cheia nodului curent este egala cu cheia cautata
    if (current != nullptr && current->getKey() == key) {
        //parcurgem nivelele nodului curent
        for (int level = 0; level < maxLevel; level++) {
            //daca nodul curent este egal cu nodul de pe nivelul curent din vectorul update
            if (update[level]->getNext()[level] == current) {
                update[level]->getNext()[level] = current->getNext()[level];
            }
        }
        //stergem nodul curent
        delete current;
        //scadem numarul de elemente din skip list
        size--;
    }
}

