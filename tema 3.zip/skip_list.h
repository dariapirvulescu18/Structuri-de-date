//
// Created by Lenovo on 6/3/2023.
//

#ifndef TEMA_3_SKIP_LIST_H
#define TEMA_3_SKIP_LIST_H

#include "node_skiped.h"
#include <iostream>
#include <vector>
#include <cmath>

class skip_list {
private:
    node_skiped* head; // Nodul de start al skip listei
    int maxLevel; // Nivelul maxim al skip listei
    int size; // Numărul de elemente din skip listă

    // Funcție pentru generarea aleatorie a nivelului unui nod nou în skip listă
    int getRandomLevel() {
        int level = 1;
        while (rand() % 2 == 0 && level < maxLevel) {
            level++;
        }
        return level;
    }

public:
    explicit skip_list(int n); // Constructor pentru skip listă, primește numărul de elemente n

    // Funcție pentru căutarea unei chei în skip listă, returnează valoarea asociată cheii sau -1 dacă cheia nu există
    int search(int key);

    // Funcție pentru inserarea unei perechi (cheie, valoare) în skip listă
    void insert(int key, int value);

    // Funcție pentru eliminarea unei chei din skip listă
    void remove(int key);
};

#endif //TEMA_3_SKIP_LIST_H
