//
// Created by Lenovo on 6/3/2023.
//

#ifndef TEMA_3_LINKED_LIST_H
#define TEMA_3_LINKED_LIST_H
#include "node.h"
#include <iostream>

class linked_list {
    node *head = nullptr, *tail = nullptr;
    int size=0;

public:
    // Inserează un nou nod în listă
    void insert(int val);

    // Afișează elementele listei
    void print();

    // Creează o listă cu n elemente
    void create_n(int n);

    // Șterge un nod cu o anumită valoare din listă
    void deletee(int valu);

    // Caută un nod cu o anumită valoare și returnează poziția sa în listă
    node * search_node(int v);


    [[nodiscard]] int getSize() const;


};


#endif //TEMA_3_LINKED_LIST_H
