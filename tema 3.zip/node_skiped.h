//
// Created by Lenovo on 6/3/2023.
//

#ifndef TEMA_3_NODE_SKIPED_H
#define TEMA_3_NODE_SKIPED_H

#include <iostream>
#include <vector>

class node_skiped {
    int key;
    int value;
    std::vector<node_skiped*> next;

public:
    // Constructor care initializează cheia cu o valoare dată și setează valoarea și vectorul next la valorile implicite
    node_skiped(int k);

    // Returnează cheia nodului
    int getKey() const;

    // Setează cheia nodului cu o valoare dată
    void setKey(int key);

    // Returnează valoarea asociată nodului
    int getValue() const;

    // Setează valoarea asociată nodului cu o valoare dată
    void setValue(int value);

    // Returnează vectorul next care conține pointeri către nodurile următoare pe niveluri
    std::vector<node_skiped*>& getNext();

    // Setează vectorul next cu un vector dat
    void setNext(const std::vector<node_skiped*>& next);
};

#endif //TEMA_3_NODE_SKIPED_H
