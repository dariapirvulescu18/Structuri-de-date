//
// Created by Lenovo on 5/5/2023.
//

#ifndef OPERATIINOD_TREE_H
#define OPERATIINOD_TREE_H

#include "node.h"
#include <string>

class tree {
    node *root = nullptr;

    // Funcție auxiliară pentru desfacerea parantezelor și construirea arborelui
    node *desface_paranteze(std::string &s, int &poz);

public:
    // Constructor care primește un nod radacina
    explicit tree(node *root);

    // Metodă pentru a obține nodul rădăcină al arborelui
    node *getRoot() const;

    // Constructor care primește o expresie matematică sub formă de șir de caractere și construiește arborele
    tree(std::string &s);

    // Metodă pentru a obține rezultatul expresiei matematice evaluate în arbore
    int get_result();
};

#endif //OPERATIINOD_TREE_H
