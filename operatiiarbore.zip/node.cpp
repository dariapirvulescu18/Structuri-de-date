//
// Created by Lenovo on 5/5/2023.
//

#include "node.h"

// Constructor care primește un caracter de operare și o valoare
node::node(char sign, int value) : sign(sign), value(value) {}

// Metodă pentru a obține caracterul de operare din nod
char node::getSign() const {
    return sign;
}

// Metodă pentru a seta caracterul de operare al nodului
void node::setSign(char sign) {
    node::sign = sign;
}

// Metodă pentru a obține valoarea stocată în nod
int node::getValue() const {
    return value;
}

// Metodă pentru a seta valoarea nodului
void node::setValue(int value) {
    node::value = value;
}

// Metodă pentru a obține nodul copil stânga
node *node::getLeft() const {
    return left;
}

// Metodă pentru a seta nodul copil stânga
void node::setLeft(node *left) {
    node::left = left;
}

// Metodă pentru a obține nodul copil dreapta
node *node::getRight() const {
    return right;
}

// Metodă pentru a seta nodul copil dreapta
void node::setRight(node *right) {
    node::right = right;
}

// Constructor fără parametri
node::node() {}
