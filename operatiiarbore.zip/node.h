//
// Created by Lenovo on 5/5/2023.
//

#ifndef OPERATIINOD_NODE_H
#define OPERATIINOD_NODE_H

class node {
    char sign = 0;          // Caracterul de operare (+, -, *, etc.)
    int value = 0;          // Valoarea stocată în nod (pentru nodurile cu numere)
    node *left = nullptr;   // Nodul copil stânga
    node *right = nullptr;  // Nodul copil dreapta
public:
    // Constructor care primește un caracter de operare și o valoare
    node(char sign, int value);

    // Constructor fără parametri
    node();

    // Metodă pentru a obține caracterul de operare din nod
    char getSign() const;

    // Metodă pentru a seta caracterul de operare al nodului
    void setSign(char sign);

    // Metodă pentru a obține valoarea stocată în nod
    int getValue() const;

    // Metodă pentru a seta valoarea nodului
    void setValue(int value);

    // Metodă pentru a obține nodul copil stânga
    node *getLeft() const;

    // Metodă pentru a seta nodul copil stânga
    void setLeft(node *left);

    // Metodă pentru a obține nodul copil dreapta
    node *getRight() const;

    // Metodă pentru a seta nodul copil dreapta
    void setRight(node *right);
};

#endif //OPERATIINOD_NODE_H
