//
// Created by Lenovo on 5/5/2023.
//

#include "tree.h"

// Constructorul clasei Tree care primește un nod rădăcină și îl atribuie membrului root
tree::tree(node *root) : root(root) {}

// Getter pentru nodul rădăcină
node *tree::getRoot() const {
    return root;
}

// Constructorul clasei Tree care primește un șir de caractere și construiește arborele
tree::tree(std::string &s) {
    int i = 0;
    root = desface_paranteze(s, i);
}

// Metoda care returnează rezultatul expresiei evaluate în arbore
int tree::get_result() {
    return root->getValue();
}

// Metoda privată care desface parantezele și construiește arborele de expresie
node *tree::desface_paranteze(std::string &s, int &poz) {
    // Creează un nou nod pentru a reprezenta o operație sau o valoare numerică
    node *node_operatie = new node();

    if (isdigit(s[poz])) {
        // Dacă caracterul curent este o cifră, construiește un nod cu valoarea numerică
        while (std::isdigit(s[poz])) {
            node_operatie->setValue(node_operatie->getValue() * 10 + s[poz] - '0');
            poz++;
        }
        ++poz;
    } else {
        // Dacă caracterul curent este un operator, construiește un nod pentru operația respectivă
        ++poz;
        node_operatie->setSign(s[poz]);
        ++poz;

        // Construiește subarborele stâng și subarborele drept recursiv
        node_operatie->setLeft(desface_paranteze(s, poz));
        node_operatie->setRight(desface_paranteze(s, poz));

        // Evaluează rezultatul operației și actualizează valoarea nodului
        switch (node_operatie->getSign()) {
            case '+':
                node_operatie->setValue(node_operatie->getLeft()->getValue() + node_operatie->getRight()->getValue());
                break;
            case '-':
                node_operatie->setValue(node_operatie->getLeft()->getValue() - node_operatie->getRight()->getValue());
                break;
            case '*':
                node_operatie->setValue(node_operatie->getLeft()->getValue() * node_operatie->getRight()->getValue());
                break;
            case '/':
                node_operatie->setValue(node_operatie->getLeft()->getValue() / node_operatie->getRight()->getValue());
                break;
        }
    }

    // Returnează nodul rezultat care este si rezultatul calculului
    return node_operatie;
}
