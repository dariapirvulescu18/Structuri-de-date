#include <iostream>
#include <string>
#include "tree.h"
#include <fstream>


int main() {
   //citesc expresi din fisierul input.txt
    std::ifstream fin("input.txt");
    std::string s;
    while (std::getline(fin, s)) {
        tree t(s);
        std::cout << t.get_result() << '\n';
    }
    fin.close();
//    (*(+3 4)(+5 6))
//    (*(-3 1)(+2 5))
    return  0;
}
